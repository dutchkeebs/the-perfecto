# the-perfecto
this is my version of a dactyl i nicknamed it the ''perfecto'' because its perfect for me
im fine with any changes you want to do because this is open source

WARNING 

this keyboard is still untested there isnt a build guide build at your own risk

this was made with the cosmos generator 

here is the link to that for the people who wanna build one that fits them even better
https://ryanis.cool/cosmos-beta
